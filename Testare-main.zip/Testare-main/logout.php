<?php 
session_start();
session_destroy();
//redirectare la pagina produse
header('Location:index.php');


 ?>